package com.creativelabs.sampathdummyservice.service.impl;

import org.springframework.stereotype.Service;

import com.creativelabs.sampathdummyservice.model.CcPayDetails;
import com.creativelabs.sampathdummyservice.service.CreditCardService;

@Service
public class CreditCardServiceImpl implements CreditCardService{
	
	@Override
	public boolean isverified(CcPayDetails c) {
		if(!c.getCcNo().equals("")) {
			if(!c.getPin().isEmpty()) {
				return true;
			}
		}
		return false;
	}
}
