package com.creativelabs.sampathdummyservice.service;

import com.creativelabs.sampathdummyservice.model.CcPayDetails;

public interface CreditCardService {
	boolean isverified(CcPayDetails c);
}
