package com.creativelabs.sampathdummyservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.creativelabs.sampathdummyservice.model.CcPayDetails;
import com.creativelabs.sampathdummyservice.service.CreditCardService;

@RestController
@CrossOrigin("http://localhost:8082")
@RequestMapping("/")
public class Controller {

	@Autowired
	private CreditCardService ccs;
	
	@RequestMapping(value="/ccverify",method=RequestMethod.POST)
	public boolean isVerified(@RequestBody CcPayDetails c) {
		return ccs.isverified(c);
	}
}
