package com.creativelabs.sampathdummyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SampathdummyserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(SampathdummyserviceApplication.class, args);
	}
}
