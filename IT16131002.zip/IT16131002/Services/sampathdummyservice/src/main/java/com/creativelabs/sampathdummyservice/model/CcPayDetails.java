package com.creativelabs.sampathdummyservice.model;

public class CcPayDetails {
	private String ccNo;
	private String pin;
	public String getCcNo() {
		return ccNo;
	}
	public void setCcNo(String ccNo) {
		this.ccNo = ccNo;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
}
