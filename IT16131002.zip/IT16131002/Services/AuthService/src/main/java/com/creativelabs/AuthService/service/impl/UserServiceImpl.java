package com.creativelabs.AuthService.service.impl;

import java.io.UnsupportedEncodingException;
import java.util.Base64;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.creativelabs.AuthService.model.Message;
import com.creativelabs.AuthService.model.User;
import com.creativelabs.AuthService.repository.UserRepository;
import com.creativelabs.AuthService.service.UserService;

@Service
public class UserServiceImpl implements UserService{

	@Autowired
	private UserRepository userrepository;
	
	@Override
	public User adduser(User user) {
		return userrepository.insert(user);
	}

	@Override
	public User getuser(String id) {
		return userrepository.findOneById(id);
	}

	@Override
	public List<User> getusers() {
		return userrepository.findAll();
	}

	@Override
	public User updateuser(User user) {
		return userrepository.save(user);
	}

	@Override
	public void deleteuser(String id) {
		userrepository.deleteById(id);
	}

	@Override
	public User getuserbyuname(String un) {
		return userrepository.findOneByUname(un);
	}

	@Override
	public Message vaalidateuser(User usr) {
		Message ms = new Message();
		
		System.out.println(usr.getUname());
		System.out.println(usr.getPassword());
		
		String decrequn=null;
		String decreqpw=null;
		try {
			decrequn = new String(Base64.getDecoder().decode(usr.getUname()),"UTF-8");
			decreqpw = new String(Base64.getDecoder().decode(usr.getPassword()),"UTF-8");
		} catch (UnsupportedEncodingException e) {
			e.printStackTrace();
		}
		
		User resuser = userrepository.findOneByUname(decrequn);
		
		if(resuser==null) {
			ms.setMsg(false);
			ms.setContent("User not Found.");
		}
		else if(resuser.getUname().equals(decrequn) && resuser.getPassword().equals(decreqpw)) {
			ms.setMsg(true);
			ms.setContent("Login Successful.");
		}
		else {
			ms.setMsg(false);
			ms.setContent("Invalid Password.");
		}
		return ms;
	}
}
