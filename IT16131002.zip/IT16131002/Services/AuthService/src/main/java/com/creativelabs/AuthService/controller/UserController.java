package com.creativelabs.AuthService.controller;


import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.creativelabs.AuthService.model.Message;
import com.creativelabs.AuthService.model.User;
import com.creativelabs.AuthService.service.UserService;

@RestController
@CrossOrigin(origins = "http://localhost:9000")
@RequestMapping("/authservice")
public class UserController {
	
	//@Autowired annotation is used to initialize the connection between the controller class and the service class
	@Autowired
	private UserService userservice;
	
	//once a api request comes with the URI /authservice/adduser, this method will be triggered. This method is used to store
	//new user information.
	@RequestMapping(value="/adduser", method=RequestMethod.POST)
	public User addUser(@RequestBody User user) {
		return userservice.adduser(user);
	}
	
	//this method will return a list of all the users currently available
	@RequestMapping(value="/getusers", method=RequestMethod.GET)
	public List<User> getusers() {
		return userservice.getusers();
	}
	
	//this method will return the details of the user of id specified by the path variable "id"
	@RequestMapping(value="/getuser/{id}", method=RequestMethod.GET)
	public User getUser(@PathVariable("id") String id) {
		return userservice.getuser(id);
	}
	
	//this method can be use to filter a user by username attribute
	@RequestMapping(value="/getuserbyun/{uname}", method=RequestMethod.GET)
	public User getUserByUname(@PathVariable("uname") String un) {
		return userservice.getuserbyuname(un);
	}
	
	//updating user information
	@RequestMapping(value="/updateuser", method=RequestMethod.PUT)
	public User updateUser(@RequestBody User user) {
		return userservice.updateuser(user);
	}
	
	//deleting a user using user id
	@RequestMapping(value="/deleteuser/{id}", method=RequestMethod.DELETE)
	public void deleteUser(@PathVariable("id") String id) {
		userservice.deleteuser(id);
	}
	
	//this method will return whether the given user is a valid user or not. It will create a message object which contains the status
	//of the user. 
	@RequestMapping(value="/validateuser", method=RequestMethod.POST)
	public Message validateuser(@RequestBody User usr) {
		return userservice.vaalidateuser(usr);
	}
}
