package com.creativelabs.AuthService.service;

import java.util.List;

import com.creativelabs.AuthService.model.Message;
import com.creativelabs.AuthService.model.User;

public interface UserService {
	
	User adduser(User user);
	
	User getuser(String id);
	
	List<User> getusers();
	
	User updateuser(User user);
	
	void deleteuser(String id);

	User getuserbyuname(String un);
	
	Message vaalidateuser(User usr);
}
