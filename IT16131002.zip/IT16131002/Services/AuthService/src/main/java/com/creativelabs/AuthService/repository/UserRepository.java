package com.creativelabs.AuthService.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.creativelabs.AuthService.model.User;

@Repository
public interface UserRepository extends MongoRepository<User, String>{
	User findOneById(String id);
	User findOneByUname(String uname);
}
