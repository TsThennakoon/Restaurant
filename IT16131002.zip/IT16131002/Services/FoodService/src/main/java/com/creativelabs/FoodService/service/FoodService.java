package com.creativelabs.FoodService.service;

import java.util.List;

import com.creativelabs.FoodService.model.Food;

public interface FoodService {

	Food addFood(Food food);
	
	List<Food> getFoods();
	
	Food getFood(String id);

	Food updatefood(Food food);

	void deletefood(String id);
}
