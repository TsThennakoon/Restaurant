package com.creativelabs.FoodService.service.impl;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.creativelabs.FoodService.model.Food;
import com.creativelabs.FoodService.repository.FoodRepository;
import com.creativelabs.FoodService.service.FoodService;

@Service
public class FoodServiceImpl implements FoodService{

	@Autowired
	private FoodRepository foodrepository; 
	
	@Override
	public Food addFood(Food food) {
		return foodrepository.insert(food);
	}
	
	@Override
	public List<Food> getFoods(){
		return foodrepository.findAll();
	}
	
	@Override
	public Food getFood(String id) {
		return foodrepository.findOneById(id);
	}

	@Override
	public Food updatefood(Food food) {
		return foodrepository.save(food);
	}

	@Override
	public void deletefood(String id) {
		foodrepository.deleteById(id);
		
	}
}
