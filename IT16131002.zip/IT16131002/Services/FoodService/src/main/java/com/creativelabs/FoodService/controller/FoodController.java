package com.creativelabs.FoodService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.creativelabs.FoodService.model.Food;
import com.creativelabs.FoodService.service.FoodService;


@RestController
@CrossOrigin(origins = "http://localhost:9000")
@RequestMapping("/foodservice")
public class FoodController {
	
	@Autowired
    private FoodService foodservice;
	
	@RequestMapping(value="/addfood", method = RequestMethod.POST)
    public Food addFood(@RequestBody final Food food) {

        return foodservice.addFood(food);
    }
	
	@RequestMapping(value="/getfoods", method=RequestMethod.GET)
	public List<Food> getFoods() {
		return foodservice.getFoods();
	}
	
	@RequestMapping(value="/getfood/{id}", method=RequestMethod.GET)
	public Food getFood(@PathVariable("id") String id) {
		return foodservice.getFood(id);
	}
	
	@RequestMapping(value="/updatefood", method=RequestMethod.PUT)
	public Food updateFood(@RequestBody Food food) {
		return foodservice.updatefood(food);
	}
	
	@RequestMapping(value="/deletefood/{id}", method=RequestMethod.DELETE)
	public void deleteUser(@PathVariable("id") String id) {
		foodservice.deletefood(id);
	}
}
