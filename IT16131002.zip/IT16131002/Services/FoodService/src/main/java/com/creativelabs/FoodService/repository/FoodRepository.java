package com.creativelabs.FoodService.repository;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.creativelabs.FoodService.model.Food;

@Repository
public interface FoodRepository extends MongoRepository<Food, String> {
	Food findOneById(String id);
}
