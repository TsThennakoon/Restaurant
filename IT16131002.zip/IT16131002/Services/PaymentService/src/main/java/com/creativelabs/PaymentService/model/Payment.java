package com.creativelabs.PaymentService.model;

import org.springframework.data.annotation.Id;
import org.springframework.data.mongodb.core.mapping.Document;

@Document
public class Payment {
	
	@Id
	private String paymentid;
	
	private String userid;
	private String username;
	private boolean ccpay;
	private boolean mobpay;
	private int amount;
	private CreditCard cc;
	private Mobile mob;
	public String getPaymentid() {
		return paymentid;
	}
	public void setPaymentid(String paymentid) {
		this.paymentid = paymentid;
	}
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public boolean isCcpay() {
		return ccpay;
	}
	public void setCcpay(boolean ccpay) {
		this.ccpay = ccpay;
	}
	public boolean isMobpay() {
		return mobpay;
	}
	public void setMobpay(boolean mobpay) {
		this.mobpay = mobpay;
	}
	public int getAmount() {
		return amount;
	}
	public void setAmount(int amount) {
		this.amount = amount;
	}
	public CreditCard getCc() {
		return cc;
	}
	public void setCc(CreditCard cc) {
		this.cc = cc;
	}
	public Mobile getMob() {
		return mob;
	}
	public void setMob(Mobile mob) {
		this.mob = mob;
	}	
}
