package com.creativelabs.PaymentService.service;

import java.util.List;

import com.creativelabs.PaymentService.model.Payment;

public interface PaymentService {

	Payment addpayment(Payment payment);
	
	List<Payment> getpayments();
	
	List<Payment> getpaymentsbyuname(String username);
	
	Payment getpaymentbyid(String paymentid);
}
