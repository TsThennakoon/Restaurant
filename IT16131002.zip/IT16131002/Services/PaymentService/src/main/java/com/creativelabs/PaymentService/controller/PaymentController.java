package com.creativelabs.PaymentService.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.creativelabs.PaymentService.model.Payment;
import com.creativelabs.PaymentService.service.PaymentService;

@RestController
@CrossOrigin(origins = "http://localhost:9000")
@RequestMapping("/paymentservice")
public class PaymentController {

	@Autowired
	private PaymentService payservice;
	
	@RequestMapping(value="/addpayment", method=RequestMethod.POST)
	public Payment addpayment(@RequestBody Payment payment){
		return payservice.addpayment(payment);
	}
	
	@RequestMapping(value="/getpayment/{paymentid}", method=RequestMethod.GET)
	public Payment getpaymentbyid(@PathVariable("paymentid") String paymentid){
		return payservice.getpaymentbyid(paymentid);
	}
	
	@RequestMapping(value="/getpayments", method=RequestMethod.GET)
	public List<Payment> getpayments() {
		return payservice.getpayments();
	}
	
	@RequestMapping(value="/getpayments/{username}", method=RequestMethod.GET)
	public List<Payment> getpaymentsbyun(@PathVariable("username") String username) {
		return payservice.getpaymentsbyuname(username);
	}
}
