package com.creativelabs.PaymentService.service.impl;

import java.io.BufferedInputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.List;

import org.apache.commons.io.IOUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.creativelabs.PaymentService.model.Payment;
import com.creativelabs.PaymentService.repository.PaymentRepository;
import com.creativelabs.PaymentService.service.PaymentService;

@Service
public class PaymentServiceImpl implements PaymentService{

	@Autowired
	private PaymentRepository payrepo;

	@Override
	public Payment addpayment(Payment payment) {
		
		if(payment.isMobpay()) {
			String mobno = payment.getMob().getMobileNo();
			String pin = payment.getMob().getPin();
			
			String tosend = "{\"mobileNo\":\""+mobno+"\",\"pin\":\""+pin+"\"}";
			System.out.println(tosend);
			if(sendrequest("http://localhost:8086/mobverify", tosend)) {
				return payrepo.insert(payment);
			}
			else {
				return null;
			}
		}
		else if(payment.isCcpay()) {
			String ccno = payment.getCc().getCcNo();
			String pin = payment.getCc().getPin();
			
			String tosend = "{\"ccNo\":\""+ccno+"\",\"pin\":\""+pin+"\"}";
			System.out.println(tosend);
			if(sendrequest("http://localhost:8085/ccverify", tosend)) {
				return payrepo.insert(payment);
			}
			else {
				return null;
			}
		}
		else {
			return null;
		}	
	}
	
	@Override
	public List<Payment> getpayments() {
		return payrepo.findAll();
	}
	
	@Override
	public List<Payment> getpaymentsbyuname(String uname) {
		return payrepo.findAllByUsername(uname);
	}
	
	@Override
	public Payment getpaymentbyid(String paymentid) {
		return payrepo.findOneByPaymentid(paymentid);
	}
	
	private boolean sendrequest(String requrl, String body){

        try {
	        URL url = new URL(requrl);
	        HttpURLConnection conn = (HttpURLConnection) url.openConnection();
	        conn.setConnectTimeout(5000);
	        conn.setRequestProperty("Content-Type", "application/json; charset=UTF-8");
	        conn.setDoOutput(true);
	        conn.setDoInput(true);
	        conn.setRequestMethod("POST");
	        OutputStream os = conn.getOutputStream();
	        os.write(body.getBytes("UTF-8"));
	        os.close(); 
	        // read the response
	        InputStream in = new BufferedInputStream(conn.getInputStream());
	        String result = IOUtils.toString(in, "UTF-8");
	        System.out.println(result);
	        in.close();
	        conn.disconnect();
	        if(result.equals("true")) {
	        	return true;
	        }
	        else {
	        	return false;
	        }
        } catch (Exception e) {
			System.out.println(e);
			return false;
		}
	}
}
