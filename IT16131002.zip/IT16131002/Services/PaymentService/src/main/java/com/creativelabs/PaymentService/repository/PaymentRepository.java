package com.creativelabs.PaymentService.repository;

import java.util.List;

import org.springframework.data.mongodb.repository.MongoRepository;
import org.springframework.stereotype.Repository;

import com.creativelabs.PaymentService.model.Payment;

@Repository
public interface PaymentRepository extends MongoRepository<Payment,String>{
	
	Payment findOneByPaymentid(String paymentid);
	
	List<Payment> findAllByUsername(String username);
}
