package com.creativelabs.PaymentService.model;

public class CreditCard {
	private String ccNo;
	private String pin;
	
	public String getCcNo() {
		return ccNo;
	}
	
	public void setCcNo(String ccNo) {
		this.ccNo = ccNo;
	}
	
	public String getPin() {
		return pin;
	}
	
	public void setPin(String pin) {
		this.pin = pin;
	}
}
