package com.creativelabs.dialogdummyservice.service.impl;

import org.springframework.stereotype.Service;

import com.creativelabs.dialogdummyservice.model.MobPayDetails;
import com.creativelabs.dialogdummyservice.service.VerificationService;

@Service
public class VerificationServiceImpl implements VerificationService{

	public boolean isverified(MobPayDetails d) {
		if((d.getMobileNo().startsWith("077") || d.getMobileNo().startsWith("076")) && d.getMobileNo().length()==10) {
			if(!d.getPin().isEmpty()) {
				return true;
			}
		}
		return false;
	}
	
}
