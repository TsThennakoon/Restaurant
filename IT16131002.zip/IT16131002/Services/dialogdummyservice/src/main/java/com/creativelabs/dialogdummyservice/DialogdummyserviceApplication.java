package com.creativelabs.dialogdummyservice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DialogdummyserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(DialogdummyserviceApplication.class, args);
	}
}
