package com.creativelabs.dialogdummyservice.service;

import com.creativelabs.dialogdummyservice.model.MobPayDetails;

public interface VerificationService {
	boolean isverified(MobPayDetails d);
}
