package com.creativelabs.dialogdummyservice.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RestController;

import com.creativelabs.dialogdummyservice.model.MobPayDetails;
import com.creativelabs.dialogdummyservice.service.VerificationService;

@RestController
@CrossOrigin("http://localhost:8082")
@RequestMapping("/")
public class Controller {
	
	@Autowired
	private VerificationService vs;
	
	@RequestMapping(value="/mobverify",method=RequestMethod.POST)
	public boolean isVerified(@RequestBody MobPayDetails d) {
		return vs.isverified(d);
	}
}
