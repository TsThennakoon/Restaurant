package com.creativelabs.dialogdummyservice.model;

public class MobPayDetails {
	private String mobileNo;
	private String pin;
	
	public String getMobileNo() {
		return mobileNo;
	}
	public void setMobileNo(String mobileNo) {
		this.mobileNo = mobileNo;
	}
	public String getPin() {
		return pin;
	}
	public void setPin(String pin) {
		this.pin = pin;
	}
}
