function validatelogin() {
    $.ajax({
    	 xhrFields: {
    	        withCredentials: true
    	    },
    	    beforeSend: function (xhr) {
    	        xhr.setRequestHeader('Authorization', 'Basic ' + btoa('admin:password123', true));
    	    },
        url: "http://localhost:8083/authservice/validateuser"
    }).then(function(data, status, jqxhr) {
    	console.log("resopnse "+ data);
       $("#msg").text(data.content);
       console.log(jqxhr);
    });
};

function verifylogin(){	
	var usrname = $("#username").val();
	var pw = $("#password").val();
	var encryptedusrname = window.btoa(usrname);
	var encryptedpassword = window.btoa(pw);

	var user = "{\"uname\":\""+encryptedusrname+"\",\"password\":\""+encryptedpassword+"\"}";
	
	jQuery.ajax({
		url : "http://localhost:8083/authservice/validateuser",
		type : "POST",
        contentType: "application/json",  
        dataType:'json',
        data :user,
        success: function(data, textStatus, errorThrown) {
        	console.log(data);
        	if(data.msg){
        		localStorage.currentuser = usrname;
        		window.location.replace("http://localhost:9000/main");
        	}
        	else{
        		$("#msg").text(data.content+" Try Again!");
        		window.alert(data.content+" Try Again!");
        	}
        },
        error : function(jqXHR, textStatus, errorThrown) {
        	 		$("#msg").text("Server Error. Try Again!");
        	 		window.alert("Server Error. Try Again!");
        },
        timeout: 120000,
    });
};