var itemsInCart;
var dbfoods;
var tot;

window.onload = function() {
	itemsInCart = JSON.parse(localStorage.cart);
	dbfoods = JSON.parse(localStorage.dbfoods);
	console.log(itemsInCart);
	console.log(dbfoods);
	listcart();
}


function listcart(){
	
	const tblContainer = document.getElementById('carttable');
		const table = document.createElement('table');
			const tr1 = table.insertRow(0);
			const tc1 = tr1.insertCell(0);
					tc1.innerHTML = "Name";
			const tc2 = tr1.insertCell(1);
					tc2.innerHTML="Quantity";
			const tc3 = tr1.insertCell(2);
					tc3.innerHTML="Unit Price";
			const tc4 = tr1.insertCell(3);
					tc4.innerHTML="SubNet";
		table.appendChild(tr1);
	tblContainer.appendChild(table);
	
	var totprice=0;
	
	itemsInCart.forEach(i => {
		var nextrow = 1;
		
		var itemname;
		var itemprice;
		var netprice;
		var orderedQty = i.quantity;
		
		dbfoods.forEach(j => {
			if(i.itemno==j.id){
				itemname=j.name;
				itemprice=j.price;
			}
		});
		netprice = itemprice*orderedQty;
		totprice = totprice + netprice;
		console.log("food items ordered:");
		console.log("name "+ itemname);
		console.log("price "+itemprice);
		console.log("quantity "+orderedQty);
		console.log("netprice "+netprice);
		const tr = table.insertRow(nextrow);
		const tc1 = tr.insertCell(0);
				tc1.innerHTML = itemname;
		const tc2 = tr.insertCell(1);
				tc2.innerHTML = orderedQty;
		const tc3 = tr.insertCell(2);
				tc3.innerHTML = itemprice;
		const tc4 = tr.insertCell(3);
				tc4.innerHTML= netprice;
		table.appendChild(tr);
	});
	tot = totprice.toString();
	console.log(tot);
	document.getElementById('totprice').textContent = `Total : ${tot}`;
}


function payviaMobile(){
	document.getElementById('paymentdetails').innerHTML = "";
	
	const mobContainer = document.getElementById('paymentdetails');
	
	const divMobno = document.createElement('div');
		const txtMobno = document.createElement('input');
		txtMobno.setAttribute('style', 'float: right;');
		txtMobno.setAttribute('class', 'paydetails');
		txtMobno.setAttribute('id', 'txtmobno');
		txtMobno.setAttribute('type', 'number');
		txtMobno.setAttribute("placeholder", "Enter Mobile number here");
		divMobno.appendChild(txtMobno);
	mobContainer.appendChild(divMobno);
	
	mobContainer.appendChild(document.createElement('br'));
	mobContainer.appendChild(document.createElement('br'));
	mobContainer.appendChild(document.createElement('br'));
	mobContainer.appendChild(document.createElement('br'));
	
	const divMobpin = document.createElement('div');
		const txtMobpin = document.createElement('input');
		txtMobpin.setAttribute('style', 'float: right;');
		txtMobpin.setAttribute('class', 'paydetails');
		txtMobpin.setAttribute('id', 'txtmobpin');
		txtMobpin.setAttribute('type', 'number');
		txtMobpin.setAttribute("placeholder", "Enter Mobile pin here");
		divMobpin.appendChild(txtMobpin);
	mobContainer.appendChild(divMobpin);
	
	mobContainer.appendChild(document.createElement('br'));
	mobContainer.appendChild(document.createElement('br'));
	mobContainer.appendChild(document.createElement('br'));
	mobContainer.appendChild(document.createElement('br'));
	
		const b = document.createElement("BUTTON");
		var t = document.createTextNode("Confirm");
	    //b.setAttribute("class","paydetails");
	    b.setAttribute("id","btnmobpay");
	    b.setAttribute("onclick","doMobpay()");
	    b.appendChild(t);
	    mobContainer.appendChild(b);

}

function payviaCC(){
	document.getElementById('paymentdetails').innerHTML = "";
	
	const ccContainer = document.getElementById('paymentdetails');
	
		const divCCno = document.createElement('div');
			const txtCCno = document.createElement('input');
			txtCCno.setAttribute('style', 'float: right;');
			txtCCno.setAttribute('class', 'paydetails');
			txtCCno.setAttribute('id', 'txtccno');
			txtCCno.setAttribute('type', 'number');
			txtCCno.setAttribute("placeholder", "Enter CreditCard number here");
			divCCno.appendChild(txtCCno);
		ccContainer.appendChild(divCCno);
		
		ccContainer.appendChild(document.createElement('br'));
		ccContainer.appendChild(document.createElement('br'));
		ccContainer.appendChild(document.createElement('br'));
		ccContainer.appendChild(document.createElement('br'));
		
		const divCCpin = document.createElement('div');
			const txtCCpin = document.createElement('input');
			txtCCpin.setAttribute('style', 'float: right;');
			txtCCpin.setAttribute('class', 'paydetails');
			txtCCpin.setAttribute('id', 'txtccpin');
			txtCCpin.setAttribute('type', 'number');
			txtCCpin.setAttribute("placeholder", "Enter CreditCard CSC here");
			divCCpin.appendChild(txtCCpin);
		ccContainer.appendChild(divCCpin);
		
		ccContainer.appendChild(document.createElement('br'));
		ccContainer.appendChild(document.createElement('br'));
		ccContainer.appendChild(document.createElement('br'));
		ccContainer.appendChild(document.createElement('br'));
		
			const b = document.createElement("BUTTON");
			var t = document.createTextNode("Confirm");
		    //b.setAttribute("class","paydetails");
		    b.setAttribute("id","btnccpay");
		    b.setAttribute("onclick","doCCpay()");
		    b.appendChild(t);
		    ccContainer.appendChild(b);
}

function doCCpay(){
	
	var ccno = document.getElementById('txtccno').value;
	var ccpin = document.getElementById('txtccpin').value;
	
	if(ccno==='' || ccpin===''){
		window.alert("Invalid payment infomation.");
	}
	else{
	
		var id = (Date.now().toString(36) + Math.random().toString(36).substr(2, 5)).toUpperCase();
		var currentuser = localStorage.currentuser;
		var billamount = tot;
		
		console.log(id);
		console.log(currentuser);
		console.log(billamount);
		console.log(ccno);
		console.log(ccpin);
		
		var payobj = new Object();
		
		payobj.paymentid = id;
		payobj.userid = "";
		payobj.username = currentuser;
		payobj.ccpay = true;
		payobj.mobpay = false;
		payobj.amount = billamount;
		
		var ccinfo = new Object();
		ccinfo.ccNo = ccno;
		ccinfo.pin = ccpin;
		
		payobj.cc = ccinfo;
		
		var mobinfo = new Object();
		mobinfo.mobileNo = "";
		mobinfo.pin = "";
		
		payobj.mob = mobinfo;
		
		console.log(payobj);
		
		var ccjson = JSON.stringify(payobj);
		
		console.log(ccjson);
		
		
		jQuery.ajax({
			url : "http://localhost:8082/paymentservice/addpayment",
			type : "POST",
	        contentType: "application/json",  
	        dataType:'json',
	        data :ccjson,
	        success: function(data, textStatus, errorThrown) {
	        	console.log(data);
	        	if(data!=null){
	        		window.alert("Your order has been confirmed. Thank you.");
	        		window.location.replace("http://localhost:9000/main");
	        	}
	        	else{
	        		//$("#msg").text(data.content+" Try Again!");
	        		window.alert(data.content+" Something happened!. Try Again!");
	        	}
	        },
	        error : function(jqXHR, textStatus, errorThrown) {
	        	 		window.alert("Invalid Payment Info.. Try Again!");
	        },
	        timeout: 120000,
	    });
	}
}

function doMobpay(){
	
	var mobno = document.getElementById('txtmobno').value;
	var mobpin = document.getElementById('txtmobpin').value;
	
	if(mobno==='' || mobpin===''){
		window.alert("Invalid payment infomation.");
	}
	else{
		var id = (Date.now().toString(36) + Math.random().toString(36).substr(2, 5)).toUpperCase();
		var currentuser = localStorage.currentuser;
		var billamount = tot;
		
		console.log(id);
		console.log(currentuser);
		console.log(billamount);
		console.log(mobno);
		console.log(mobpin);
		
		var payobj = new Object();
		
		payobj.paymentid = id;
		payobj.userid = "";
		payobj.username = currentuser;
		payobj.ccpay = false;
		payobj.mobpay = true;
		payobj.amount = billamount;
		
		var mobinfo = new Object();
		mobinfo.mobileNo = mobno;
		mobinfo.pin = mobpin;
		
		payobj.mob = mobinfo;
		
		var ccinfo = new Object();
		ccinfo.ccNo = "";
		ccinfo.pin = "";
		
		payobj.cc = ccinfo;
		
		console.log(payobj);
		
		var mobjson = JSON.stringify(payobj);
		
		console.log(mobjson);
		
		
		jQuery.ajax({
			url : "http://localhost:8082/paymentservice/addpayment",
			type : "POST",
	        contentType: "application/json",  
	        dataType:'json',
	        data :mobjson,
	        success: function(data, textStatus, errorThrown) {
	        	console.log(data);
	        	if(data!=null){
	        		window.alert("Your order has been confirmed. Thank you.");
	        		window.location.replace("http://localhost:9000/main");
	        	}
	        	else{
	        		window.alert(data.content+" Something happened!. Try Again!");
	        	}
	        },
	        error : function(jqXHR, textStatus, errorThrown) {
	        	 		window.alert("Invalid Payment Info. Try Again!. Use Dialog Mobile Numbers only.");
	        },
	        timeout: 120000,
	    });
	}
}