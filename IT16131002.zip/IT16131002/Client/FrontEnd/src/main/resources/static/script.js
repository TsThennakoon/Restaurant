
var data;

var cartitems=[];
const app = document.getElementById('root');

const logo = document.createElement('img');
logo.src = 'banner.png';
//app.appendChild(logo);

const container = document.createElement('div');
container.setAttribute('class', 'container');

app.appendChild(container);
var request = new XMLHttpRequest();
request.open('GET', 'http://localhost:8081/foodservice/getfoods', true);
request.onload = function () {

  // Begin accessing JSON data here
  data = JSON.parse(this.response);
  localStorage.dbfoods = JSON.stringify(data);
  console.log(data);
  if (request.status >= 200 && request.status < 400) {
    data.forEach(food => {
      const card = document.createElement('div');
      card.setAttribute('class', 'card');

      const h1 = document.createElement('h1');
      h1.textContent = food.name;
      h1.setAttribute("id","name"+food.id);

      const p = document.createElement('p');

      p.textContent = `Price : ${food.price}`;
      p.setAttribute("id","price"+food.id);
      
      var x = document.createElement("INPUT");
      x.setAttribute("type", "number");
      //x.setAttribute("value", "0");
      x.setAttribute("placeholder", "Enter Quantity");
      x.setAttribute("id","txt"+food.id);
      
      const b = document.createElement("BUTTON");
      var t = document.createTextNode("Add to Cart");
      b.setAttribute("class","addtocart");
      b.setAttribute("id",food.id);
      b.setAttribute("onclick","addtocart(this.id)");
      b.appendChild(t);
      
      const p2 = document.createElement("p");
      
      container.appendChild(card);
      card.appendChild(h1);
      card.appendChild(p);
      card.appendChild(x);
      card.appendChild(b);
      card.appendChild(p2);
      
      
    });
  } else {
    const errorMessage = document.createElement('marquee');
    errorMessage.textContent = `Not working!`;
    app.appendChild(errorMessage);
  }
}

request.send();

function gotocart() {
	//localStorage.setItem("cartitems",cartitems);
	localStorage.cart = JSON.stringify(cartitems);
	window.location.replace("http://localhost:9000/cart");
};

function addtocart(id){
	
	var qty = document.getElementById("txt"+id).value;
	console.log(qty);
	
	if(qty!=""){
		var cartitem = new Object();
		cartitem.itemno = id;
		cartitem.quantity = parseInt(qty);
		
		console.log(cartitem);
		
		cartitems.push(cartitem);
		console.log(cartitems);
		
		document.getElementById("txt"+id).value="";
	}
}
