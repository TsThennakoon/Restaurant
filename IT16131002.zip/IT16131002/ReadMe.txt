ID    : IT16131002
Name  : A.M.H.B.Athapaththu
Email : hiranthaathapaththu@gmail.com
Phone : 0769065565


1) Importing Database

	This system use mongo db as the database. To import existing data to the database.

	Copy "dump" folder inside the DBBackup folder to the "bin" folder of the mongo db insallation directry.

	Open a command prompt as the administrator inside the bin folder.

	then type "mongorestore" inside the command prompt and press enter.

	if successful, you should have 3 databases called "fooddb","paymentdb" and "userdb" inside mongodb.

	make sure mongodb is running before executing the services.


2) Deploying Services

	**Requirements

		-Spring Tool Suite or Eclipse IDE
		-Mongo Database
		-Internet for downloading dependencies

	there are 5 services and 1 frontend for this project
	
	Client
	-----	
		FrontEnd

	Services
	--------	
		AuthService
		FoodService
		PaymentService
		sampathdummyservice
		dialogdummyservice

	*Using IDE
		Open all services and the front-end using eclipse IDE (Recommended : Spring Tool Suite) and run as spring application

				OR

	*Package each service using maven packaging command "mvn package"
		
		go to target folder and run the snapshot jar files of the each service using the command "java -jar <filename>.jar"
3) Testing

	go to your browser and go to http://localhost:9000/

	to login, use Username = admin , Password = admin


****Note that this system uses port 8081, 8082, 8083, 8085, 8086 and 9000. So make sure that those ports ant not beying used by other applications.